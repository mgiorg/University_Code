
import java.util.*;

public class InvertiLista {

	public static void invertiLista(LinkedList<Integer> list) {
		//TODO: Da completare
	}
}
