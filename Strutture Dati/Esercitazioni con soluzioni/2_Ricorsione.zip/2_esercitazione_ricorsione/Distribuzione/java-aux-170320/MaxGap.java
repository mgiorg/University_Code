public class MaxGap {

    public static int maxGap(int[] array, int start, int end) {
      	//TODO: Da Completare
		return 0;
    }
}
