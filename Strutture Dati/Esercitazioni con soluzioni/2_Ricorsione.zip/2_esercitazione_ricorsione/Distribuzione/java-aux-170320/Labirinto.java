public class Labirinto {

	private static enum Cella { VUOTA, PIENA };

	private int n;
    private Cella m[][];
    private boolean marcata[][];

  public Labirinto(int n) {
		//TODO: Da Completare
  }

	public void setPiena(int r, int c){
		//TODO: Da Completare
  }

	private boolean uscita(int r, int c){
  		//TODO: Da Completare
		return false;
  }

	public boolean percorribile(int r, int c){
  		//TODO: Da Completare
		return false;
  }

	private boolean uscitaRaggiungibileDa(int r, int c){
		//TODO: Da Completare
		return false;
	}

	public boolean risolvibile(){
		//TODO: Da Completare
		return false;
	}

	public String toString() {
		//TODO: Da Completare
		return null;
	}
}
