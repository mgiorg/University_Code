#Scrivere un programma che prende in input una stringa s 
#e un intero n e stampa la stringa s ripetuta n volte. 
#Ad esempio se la stringa è ‘casa’ e l’intero è 3 il programma deve stampare ‘casacasacasa’.

s = input("Inserire una stringa: ")
n = int(input("Quante volte la devo ripetere? "))

print(s*n)