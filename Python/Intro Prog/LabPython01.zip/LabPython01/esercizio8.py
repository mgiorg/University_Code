#Scrivere un programma che prenda in ingresso una stringa (s) 
#e stampa la stringa un numero di volte pari alla sua lunghezza.

s = input("Inserire stringa: ")
n = len(s)

print(s*n)