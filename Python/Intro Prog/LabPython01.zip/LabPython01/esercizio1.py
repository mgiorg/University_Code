#Quadrato del numero intero

a = input('Inserire numero intero: ')
b = int(float(a))
c = b**2
print('Il quadrato del numero intero è: ', c)