
public class MatriceSparsa {

	private class Elem{

	}


	public MatriceSparsa(int m, int n) {

	}

	public int getNumRow() {
		// TODO: Implement here
		return 0;
	}

	public int getNumCol() {
		// TODO: Implement here
		return 0;
	}

	public void set(int i, int j, int x) {
		// TODO: Implement here
	}

	public int get(int i, int j) {
		// TODO: Implement here
		return 0;
	}

	public String toString() {
		// TODO: Implement here
		return null;
	}

	public MatriceSparsa add(MatriceSparsa mat1, MatriceSparsa mat2) {
		// TODO: Implement here
		return null;
	}

	public MatriceSparsa tra(MatriceSparsa mat1, MatriceSparsa mat2) {
		// TODO: Implement here
		return null;
	}

	public MatriceSparsa mul(MatriceSparsa mat1, MatriceSparsa mat2) {
		// TODO: Implement here
		return null;
	}
}
