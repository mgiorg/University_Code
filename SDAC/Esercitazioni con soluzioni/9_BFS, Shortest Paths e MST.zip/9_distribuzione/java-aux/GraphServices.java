import java.util.*;

public class GraphServices {

	
	public static <V> void bfs(Graph<V> g) {
		
	}

	public static <V> void sssp(Graph<V> g, Node<V> source) {

	}
	
	public static <V> void mst(Graph<V> G) {
		
	}
}




