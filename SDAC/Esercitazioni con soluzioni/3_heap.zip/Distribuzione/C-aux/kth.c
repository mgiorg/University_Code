#include <stdlib.h>

#include "heap.h"
#include "kth.h"

kth * kth_new(int k) {
	return NULL;
}

void kth_insert(kth * dd, int key) {
	return;
}

int kth_get(kth * dd) {
	return 0;
}

void kth_remove(kth * dd) {
	return;
}

void kth_delete(kth * dd) {
	return;
}