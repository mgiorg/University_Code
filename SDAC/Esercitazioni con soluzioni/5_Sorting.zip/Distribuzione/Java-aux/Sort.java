import java.util.*;

public class Sort {

    /* Disponibile in libreria java */
    public void quickSortDefault(int[] array) {
        Arrays.sort(array);
    }

    public void mergeSort(int[] array) {
        System.out.println("mergeSort non è ancora implementato");
        return;
    }

    public void heapSort(int[] array) {
        System.out.println("heapSort non è ancora implementato");
        return;
    }

    public void insertionSort(int[] array) {
        System.out.println("insertionSort non è ancora implementato");
        return;
    }

    public void selectionSort(int[] array) {
        System.out.println("selectionSort non è ancora implementato");
        return;
    }

    public void quickSort(int[] array) {
        System.out.println("quickSort non è ancora implementato");
        return;
    }

    public void radixSort(int[] array) {
        System.out.println("radixSort non è ancora implementato");
        return;
    }

    public void bucketSort(int[] array) {
        System.out.println("bucketSort non è ancora implementato");
        return;
    }
}
