#include <stdio.h>


#include "sort.h"

void mergeSort(array *a) {
    fprintf(stdout, "mergeSort currently not implemented.\n");
    return;
}

void heapSort(array *a) {
    fprintf(stdout, "heapSort currently not implemented.\n");
    return;
}

void insertionSort(array *a) {
    fprintf(stdout, "insertionSort currently not implemented.\n");
    return;
}

void selectionSort(array *a) {
    fprintf(stdout, "selectionSort currently not implemented.\n");
    return;
}

void quickSort(array *a) {
    fprintf(stdout, "quickSort currently not implemented.\n");
    return;
}

void radixSort(array *a) {
    fprintf(stdout, "radixSort currently not implemented.\n");
    return;
}

void bucketSort(array *a) {
    fprintf(stdout, "bucketSort currently not implemented.\n");
    return;
}

